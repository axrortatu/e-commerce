package uz.pdp.restservice.service.base;

public interface ResponseMessage {
    String SUCCESS = "SUCCESS";

}
