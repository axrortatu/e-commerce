package uz.pdp.restservice.model.admin.receive;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgentReceiveDto {
    private String name;
}
